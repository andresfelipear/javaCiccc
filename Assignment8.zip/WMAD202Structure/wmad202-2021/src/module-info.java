module ca.ciccc.wmad202 {
    requires ca.ciccc.wmad202.assigment1;
    requires wmad202.assignment2;
    requires wmad202.assignment3;
    requires wmad202.assignment4;
    requires wmad202.assignment5;
    requires wmad202.assignment6;
    requires wmad202.assignment7;
    requires wmad202.assignment8;
    requires wmad202.assignment9;

}