package ca.bcit.main.main;

import ca.ciccc.wmad202.assignment9.main.Assignment9Driver;

public class WMAD202Driver {
    public static void main(String[] args){
        //Assignment1Driver.run();
        //Assignment2Driver.run();
        //Assignment3Driver.run();
        //Assignment4Driver.run();
        //Assignment5Driver.run();
        //Assignment6Driver.run();
        //Assignment7Driver.run();
        //Assignment8Driver.run();
        Assignment9Driver.run();
    }
}
