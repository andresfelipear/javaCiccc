package ca.ciccc.wmad202.assignment9.assignment1.question1;

public class Question1 {
    public static void sampleMethod(){
        System.out.println("Assignment1 - Question1 Done");
    }
}
