module ca.ciccc.wmad202.assigment1{
    exports ca.ciccc.wmad202.assignment9.assignment1.main;
}