package ca.ciccc.wmad202.assignment9.assignment6.problem2.problem22;

public class Words {
    private String word;
    public Words(String word){
        this.word = word;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }
}
