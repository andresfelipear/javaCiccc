module wmad202.assignment6 {
    exports ca.ciccc.wmad202.assignment9.assignment6.main;
}