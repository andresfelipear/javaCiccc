package ca.ciccc.wmad202.assignment9.main;

import ca.ciccc.wmad202.assignment9.problem1.Foo1;
import ca.ciccc.wmad202.assignment9.problem5.BiConsumerExample;
import ca.ciccc.wmad202.assignment9.problem5.ConsumerExample;
import ca.ciccc.wmad202.assignment9.problem5.FunctionExample;
import ca.ciccc.wmad202.assignment9.problem6.ToStringFunctionExample;

public class Assignment9Driver {
    public static void run(){

        //Foo1.Test64.test();
        //Problem5
        BiConsumerExample.test();
        ConsumerExample.test();
        FunctionExample.test();
        ToStringFunctionExample.test();
    }
}
