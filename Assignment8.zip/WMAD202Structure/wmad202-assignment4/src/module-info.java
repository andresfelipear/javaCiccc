module wmad202.assignment4 {
    exports ca.ciccc.wmad202.assignment9.assignment4.main;
}