module wmad202.assignment5 {
    exports ca.ciccc.wmad202.assignment9.assignment5.main;
}