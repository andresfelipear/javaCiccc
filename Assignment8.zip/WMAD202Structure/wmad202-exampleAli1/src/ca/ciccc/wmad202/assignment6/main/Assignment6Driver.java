package ca.ciccc.wmad202.assignment6.main;

import ca.ciccc.wmad202.assignment6.main.example.TestExample;

public class Assignment6Driver {

    public static void run() {
        System.out.println("Assignment6-Example");

        TestExample.test();
    }
}
