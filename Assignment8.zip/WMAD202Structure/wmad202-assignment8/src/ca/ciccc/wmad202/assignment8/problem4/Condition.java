package ca.ciccc.wmad202.assignment8.problem4;

public interface Condition<E> {
    public boolean evaluate(E item);
}
