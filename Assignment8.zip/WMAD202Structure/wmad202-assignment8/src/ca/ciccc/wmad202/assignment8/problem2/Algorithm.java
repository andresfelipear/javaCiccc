package ca.ciccc.wmad202.assignment8.problem2;

public final class Algorithm {
    public static <T> T max(T x, T y){
        return x.equals(y)? x : y;
    }
}
