package ca.ciccc.wmad202.assignment8.main;

import ca.ciccc.wmad202.assignment8.problem5.Problem5;
import ca.ciccc.wmad202.assignment8.problem4.Problem4;
import ca.ciccc.wmad202.assignment8.problem1.Problem1;
import ca.ciccc.wmad202.assignment8.problem3.Problem3;

public class Assignment8Driver {
    public static void run(){
        System.out.println("Problem1");
        Problem1.test();
        System.out.println("Problem3");
        Problem3.test();
        System.out.println("Problem4");
        Problem4.test();
        System.out.println("Problem5");
        Problem5.test();
    }

}
