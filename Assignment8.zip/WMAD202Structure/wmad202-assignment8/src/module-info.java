module wmad202.assignment8 {
    exports ca.ciccc.wmad202.assignment8.main;
}