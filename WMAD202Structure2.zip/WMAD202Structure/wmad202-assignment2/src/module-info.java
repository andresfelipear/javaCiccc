module wmad202.assignment2 {
    exports ca.ciccc.wmad202.assignment2.main;
}