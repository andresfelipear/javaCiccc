module ca.ciccc.wmad202 {
    requires ca.ciccc.wmad202.assigment1;
    requires wmad202.assignment2;
    requires wmad202.assignment3;
}