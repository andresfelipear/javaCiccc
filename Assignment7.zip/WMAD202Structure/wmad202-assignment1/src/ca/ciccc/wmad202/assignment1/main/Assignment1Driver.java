package ca.ciccc.wmad202.assignment1.main;

import ca.ciccc.wmad202.assignment1.question1.Question1;

public class Assignment1Driver {
    public static void run() {
        System.out.println("Assignment1");
        Question1 q1 = new Question1();
        q1.sampleMethod();
    }
}
