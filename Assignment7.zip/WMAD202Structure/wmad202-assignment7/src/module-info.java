module wmad202.assignment7 {
    exports ca.ciccc.wmad202.assignment7.main;
}