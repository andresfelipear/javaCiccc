package ca.ciccc.wmad202.assignment7.problem1;

public class Material {
    private Integer materialCode;
    private String materialName;
    public Material(Integer materialCode, String materialName){
        this.materialCode = materialCode;
        this.materialName = materialName;
    }
}
