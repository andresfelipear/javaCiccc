module wmad202.assignment3 {
    exports ca.ciccc.wmad202.assignment3.main;
}