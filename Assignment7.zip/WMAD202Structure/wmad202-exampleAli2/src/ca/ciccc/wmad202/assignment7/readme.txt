

Create a search method which searches a list of items and returns items which fulfill a specific condition.

example:

-- search a list of string and returns strings whose length are bigger than 4
-- search a list of integers and returns the integers that are divisible by 6
-- search a list of product and retunrs the producs whose prices are less thn 3 dollar
-- search a list of students whose GPA is above 75%
