package ca.ciccc.wmad202.assignment7.main;

import ca.ciccc.wmad202.assignment7.generic1.Example1;

public class Assignment7Driver {

    public static void run() {
        System.out.println("Assignment7-Example");

        Example1.test();
    }
}
