package ca.ciccc.wmad202.assignment7.generic1;

public interface Condition<E>{

    public boolean evaluate(E item);
}
