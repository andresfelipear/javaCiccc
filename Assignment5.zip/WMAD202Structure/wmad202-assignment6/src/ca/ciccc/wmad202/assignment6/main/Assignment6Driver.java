package ca.ciccc.wmad202.assignment6.main;

import ca.ciccc.wmad202.assignment6.problem1.TestClass;
import ca.ciccc.wmad202.assignment6.problem2.problem21.TestClass2;
import ca.ciccc.wmad202.assignment6.problem2.problem22.TestClass22;
import ca.ciccc.wmad202.assignment6.problem2.problem23.TestClass23;
import ca.ciccc.wmad202.assignment6.problem3.TestClass3;

public class Assignment6Driver {
    public static void run(){
//        TestClass t1 = new TestClass();
//        t1.test();
//        TestClass2 t21 = new TestClass2();
//        t21.test();
//        TestClass22 t22 = new TestClass22();
//        t22.test();
//        TestClass23 t23 = new TestClass23();
//        t23.test();
        TestClass3 t3 = new TestClass3();
        t3.test();

    }
}
